#include <iostream>
#include <fstream>
#include <sstream>
#include <stdint.h>
#include <vector>
#include <bitset>
//#include "markerlabelers/arucofidmarkers.h"
#include "dictionary.h"
using namespace std;
int main(int argc,char **argv){

//    if (argc!=2){cerr<<"Usage  out "<<endl;return -1;}

////    aruco::Dictionary aruco_dict;

//    for(int i=0;i<1024;i++){
//        cv::Mat marker=aruco::FiducidalMarkers::getMarkerMat(i);
//        //get the equivalent id
//        bitset<64> mid;int mi=0;
//        for(int i=0;i<marker.rows;i++)
//            for(int j=0;j<marker.cols;j++)
//                    mid[mi++]=marker.at<uchar>(i,j);
//    }

//    cout<<"={";
//    int i=0;
//    for(auto d:aruco_dict.getMapCode()){
//        cout<<"std::pair<uint64_t,int>("<<d.first<<","<<d.second<<")";
//        i++;
//        if (i<aruco_dict.size())cout<<",";
//    }
//    cout<<"}";

}

